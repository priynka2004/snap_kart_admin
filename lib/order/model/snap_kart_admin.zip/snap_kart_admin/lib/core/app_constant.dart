class AppConstant{
  static const String apikey = 'aihfj--qwnkqwr--jlkqwnjqw--jnkqwjnqwy';

}