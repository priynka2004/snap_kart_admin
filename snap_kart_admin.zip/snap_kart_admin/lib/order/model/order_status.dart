List<String> orderStatusList = [
  'pending',
  'shipped',
  'delivered',
  'cancelled',
];