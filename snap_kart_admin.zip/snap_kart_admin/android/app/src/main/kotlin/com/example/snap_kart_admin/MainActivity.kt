package com.example.snap_kart_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
